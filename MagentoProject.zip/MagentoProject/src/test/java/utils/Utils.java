package utils;

import common.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;


    public class Utils extends TestBase{

    public void clickOnButton(By locator) {
        WebElement element = driver.findElement(locator);
        element.click();
    }

    public void hoverOverElements(By locator) {
            Actions builder = new Actions(driver);
            WebElement element = driver.findElement(locator);
            builder.moveToElement(element).build().perform();
        }

     public void waitForElementVisible(By locator)   {
         WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
         wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
     }

    }

