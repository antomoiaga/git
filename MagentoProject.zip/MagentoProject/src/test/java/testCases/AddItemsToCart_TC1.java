package testCases;

import com.aventstack.extentreports.Status;
import common.TestBase;
import org.junit.Test;
import pages.HomePage;




public class AddItemsToCart_TC1 extends TestBase {

    @Test()
    public void adding_items_to_cart() {
        test = extent.createTest("adding items to cart", "Case 1: User is able to add items to cart")
                .assignCategory("Functional_testcase")
                .assignAuthor("QA team");
        logger.info("Verify URL");

        openURL("https://magento.softwaretestingboard.com/?ref=hackernoon.com");
        test.log(Status.INFO, "Open URL");
        logger.info("Open URL");


       utils.waitForElementVisible(HomePage.WomenBtn);
       utils.hoverOverElements(HomePage.WomenBtn);
       test.log(Status.INFO, "Hover over  Women Button(Homepage)");
       logger.info("Hover over Women Button(Homepage)");

       utils.waitForElementVisible(HomePage.TopsBtn);
       utils.hoverOverElements(HomePage.TopsBtn);
        test.log(Status.INFO, "Hover over Tops Button(Homepage)");
        logger.info("Hover over Tops Button(Homepage)");

        utils.waitForElementVisible(HomePage.HoodiesSweatshirts);
        utils.clickOnButton(HomePage.HoodiesSweatshirts);
        test.log(Status.INFO, "Click on Hoodies and Sweatshirts(Homepage)");
        logger.info("Click on Hoodies and Sweatshirts(Homepage)");
    }


}
